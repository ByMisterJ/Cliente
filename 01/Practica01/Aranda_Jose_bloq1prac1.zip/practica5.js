var articulo = parseInt(prompt("introduce el precio"))

var iva = articulo * (21/100)
console.log(parseFloat(iva))

var total = articulo + iva
console.log(parseFloat(total))