var num = prompt("introduce un numero")

if(num%2==0){
    console.log("es par")
}else console.log("es impar")