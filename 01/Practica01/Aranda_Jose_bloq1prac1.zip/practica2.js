var arrnum = [7,8,2,9,10]
var suma = 0
for (let i = 0; i < arrnum.length; i++) {
    if(arrnum[i]>8){
        suma = suma + arrnum[i]
    }
}
console.log(suma)